// streama-frontend/app.js
const registerForm = document.getElementById('registerForm');
const otpForm = document.getElementById('otpForm');
const loginForm = document.getElementById('loginForm');
const createMeetingForm = document.getElementById('createMeetingForm');

if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('registerEmail').value;
        const password = document.getElementById('registerPassword').value;

        const response = await fetch('http://localhost:4000/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password }),
        });

        if (response.ok) {
            alert('Registration successful! Please verify your OTP.');
            window.location.href = 'verify-otp.html'; // Redirect to OTP verification
        } else {
            const errorText = await response.text();
            alert(`Registration failed: ${errorText}`);
        }
    });
}

if (otpForm) {
    otpForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('otpEmail').value;
        const otp = document.getElementById('otp').value;

        const response = await fetch('http://localhost:4000/verify-otp', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, otp }),
        });

        if (response.ok) {
            alert('OTP verified successfully! You can now log in.');
            window.location.href = 'login.html'; // Redirect to login
        } else {
            const errorText = await response.text();
            alert(`OTP verification failed: ${errorText}`);
        }
    });
}

if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        const response = await fetch('http://localhost:4000/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password }),
        });

        if (response.ok) {
            alert('Login successful!');
            window.location.href = 'create-meeting.html'; // Redirect to create meeting page
        } else {
            const errorText = await response.text();
            alert(`Login failed: ${errorText}`);
        }
    });
}

if (createMeetingForm) {
    createMeetingForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const meetingDetails = document.getElementById('meetingDetails').value;

        const response = await fetch('http://localhost:4000/create-meeting', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ meetingDetails }),
        });

        if (response.ok) {
            const { meetingId } = await response.json();
            alert(`Meeting created successfully! Meeting ID: ${meetingId}`);
            // You can redirect to the meeting page or another action
        } else {
            const errorText = await response.text();
            alert(`Meeting creation failed: ${errorText}`);
        }
    });
}