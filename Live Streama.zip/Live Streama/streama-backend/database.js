// streama-backend/database.js
const users = []; // In-memory user storage (for demo purposes)

module.exports = { users };